---
type: "central-bank"
country: "DMA"
code: "N/A"
established: "unknown"
policy_rate_source: "curated/manual"
policy_rate_as_of: "N/A"
tags:
  - finance/central-bank
data_quality: "auto-stub"
last_updated: "2026-08-31 08:26 UTC"
---
# 🏛️ Central Bank of Dominica

> [!warning] Auto-generated stub
> This entity has not been manually curated yet. Policy rate and mandate are placeholders — extend `CURATED_CENTRAL_BANKS` in the daemon to enrich it.

## 📊 Policy Snapshot
<!-- LIVE:POLICY-RATE:START -->
| Metric | Value |
|---|---|
| Policy Rate | `N/A%` |
| Rate Source | curated/manual |
| Rate As Of | N/A |
| Mandate | Not yet catalogued |
| CBDC Status | Not yet catalogued |
| Data quality | 🟡 auto-stub — needs enrichment |
<!-- LIVE:POLICY-RATE:END -->

## 🔗 Graph Context
- Sovereign: [[DMA-country|Dominica]]
- All central banks: see [[Central-Banks-MOC]]

## 📝 Notes
> Add your own notes below this line — the daemon never touches this section.
