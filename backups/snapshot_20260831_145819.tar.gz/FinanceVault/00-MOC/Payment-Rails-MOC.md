---
type: "moc"
tags:
  - finance/moc
last_updated: "2026-08-30 20:06 UTC"
---
# 🗺️ Payment Rails — Map of Content

Global messaging & settlement infrastructure, with live open/closed status.

```dataview
TABLE scope, rail_type, operator FROM "30-Payment-Rails"
```

## 📝 Notes
> Add your own notes below this line — the daemon never touches this section.
