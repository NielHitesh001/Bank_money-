---
type: "payment-rail"
scope: "United States (large-value)"
rail_type: "Net settlement"
operator: "The Clearing House"
tags:
  - finance/payment-rail
last_updated: "2026-08-31 09:21 UTC"
---
# 🔌 Clearing House Interbank Payments System (CHIPS)

## ⚡ Live Status
<!-- LIVE:STATUS:START -->
| Metric | Value |
|---|---|
| Status | 🟢 OPEN |
| Operating window | 00:00–17:00 America/New_York |
| Checked at | 2026-08-31 09:21 UTC |
<!-- LIVE:STATUS:END -->

## ℹ️ Overview
- **Type:** Net settlement
- **Scope:** United States (large-value)
- **Operator:** The Clearing House
- **Notes:** Handles the bulk of USD cross-border interbank payment value.

## 🔗 Settles Currency For
- [[USA-country|USA]]

## 📝 Notes
> Add your own notes below this line — the daemon never touches this section.
