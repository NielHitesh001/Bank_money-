---
type: "country"
iso2: "DE"
iso3: "DEU"
region: "Europe"
subregion: "Western Europe"
currency: "EUR"
central_bank: "DEU-central-bank"
population: "N/A"
tags:
  - finance/country
  - region/europe
last_updated: "2026-08-31 09:03 UTC"
---
# 🏦 Germany — Financial Tear Sheet

> [!info] Quick Facts
> **Region:** Europe / Western Europe
> **Capital:** Berlin
> **Currency:** EUR
> **Central Bank:** [[DEU-central-bank|Central Bank of Germany]]

## 💱 FX Snapshot
<!-- LIVE:FXRATE:START -->
| Metric | Value |
|---|---|
| USD → EUR | `0.8589` |
| Source | ECB reference rate (via frankfurter.app) |
| As of | 2026-08-28 |
<!-- LIVE:FXRATE:END -->

## 🏛️ Monetary Authority
- [[DEU-central-bank|Central Bank of Germany]]

## 🔗 Connected Payment Rails
- [[SEPA_INSTANT-rail|SEPA Instant Credit Transfer]]
- [[SWIFT-rail|Society for Worldwide Interbank Financial Telecommunication]]
- [[TARGET2-rail|Trans-European Automated Real-time Gross settlement Express Transfer]]

## 🗺️ Graph Context
- Region MOC: [[Europe-MOC]]
- All entities of this type: `dataview` query in [[Countries-MOC]]

## 📝 Notes
> Add your own notes below this line — the daemon never touches this section.
