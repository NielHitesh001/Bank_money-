---
type: "country"
iso2: "AE"
iso3: "ARE"
region: "Asia"
subregion: "Western Asia"
currency: "AED"
central_bank: "ARE-central-bank"
population: "N/A"
tags:
  - finance/country
  - region/asia
last_updated: "2026-08-31 09:03 UTC"
---
# 🏦 United Arab Emirates — Financial Tear Sheet

> [!info] Quick Facts
> **Region:** Asia / Western Asia
> **Capital:** Abu Dhabi
> **Currency:** AED
> **Central Bank:** [[ARE-central-bank|Central Bank of United Arab Emirates]]

## 💱 FX Snapshot
<!-- LIVE:FXRATE:START -->
| Metric | Value |
|---|---|
| USD → AED | `N/A` |
| Source | ECB reference rate (via frankfurter.app) |
| As of | 2026-08-28 |
<!-- LIVE:FXRATE:END -->

## 🏛️ Monetary Authority
- [[ARE-central-bank|Central Bank of United Arab Emirates]]

## 🔗 Connected Payment Rails
- [[SWIFT-rail|Society for Worldwide Interbank Financial Telecommunication]]

## 🗺️ Graph Context
- Region MOC: [[Asia-MOC]]
- All entities of this type: `dataview` query in [[Countries-MOC]]

## 📝 Notes
> Add your own notes below this line — the daemon never touches this section.
