---
type: "country"
iso2: "GR"
iso3: "GRC"
region: "Europe"
subregion: "Southern Europe"
currency: "EUR"
central_bank: "GRC-central-bank"
population: "N/A"
tags:
  - finance/country
  - region/europe
last_updated: "2026-08-31 09:03 UTC"
---
# 🏦 Greece — Financial Tear Sheet

> [!info] Quick Facts
> **Region:** Europe / Southern Europe
> **Capital:** Athens
> **Currency:** EUR
> **Central Bank:** [[GRC-central-bank|Central Bank of Greece (stub)]]

## 💱 FX Snapshot
<!-- LIVE:FXRATE:START -->
| Metric | Value |
|---|---|
| USD → EUR | `0.8589` |
| Source | ECB reference rate (via frankfurter.app) |
| As of | 2026-08-28 |
<!-- LIVE:FXRATE:END -->

## 🏛️ Monetary Authority
- [[GRC-central-bank|Central Bank of Greece (stub)]]

## 🔗 Connected Payment Rails
- [[SWIFT-rail|Society for Worldwide Interbank Financial Telecommunication]]

## 🗺️ Graph Context
- Region MOC: [[Europe-MOC]]
- All entities of this type: `dataview` query in [[Countries-MOC]]

## 📝 Notes
> Add your own notes below this line — the daemon never touches this section.
