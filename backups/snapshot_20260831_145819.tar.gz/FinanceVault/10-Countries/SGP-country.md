---
type: "country"
iso2: "SG"
iso3: "SGP"
region: "Asia"
subregion: "South-Eastern Asia"
currency: "SGD"
central_bank: "SGP-central-bank"
population: "N/A"
tags:
  - finance/country
  - region/asia
last_updated: "2026-08-31 09:03 UTC"
---
# 🏦 Singapore — Financial Tear Sheet

> [!info] Quick Facts
> **Region:** Asia / South-Eastern Asia
> **Capital:** Singapore
> **Currency:** SGD
> **Central Bank:** [[SGP-central-bank|Central Bank of Singapore]]

## 💱 FX Snapshot
<!-- LIVE:FXRATE:START -->
| Metric | Value |
|---|---|
| USD → SGD | `1.2713` |
| Source | ECB reference rate (via frankfurter.app) |
| As of | 2026-08-28 |
<!-- LIVE:FXRATE:END -->

## 🏛️ Monetary Authority
- [[SGP-central-bank|Central Bank of Singapore]]

## 🔗 Connected Payment Rails
- [[SWIFT-rail|Society for Worldwide Interbank Financial Telecommunication]]

## 🗺️ Graph Context
- Region MOC: [[Asia-MOC]]
- All entities of this type: `dataview` query in [[Countries-MOC]]

## 📝 Notes
> Add your own notes below this line — the daemon never touches this section.
