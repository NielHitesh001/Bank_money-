---
type: "country"
iso2: "NO"
iso3: "NOR"
region: "Europe"
subregion: "Northern Europe"
currency: "NOK"
central_bank: "NOR-central-bank"
population: "N/A"
tags:
  - finance/country
  - region/europe
last_updated: "2026-08-31 09:03 UTC"
---
# 🏦 Norway — Financial Tear Sheet

> [!info] Quick Facts
> **Region:** Europe / Northern Europe
> **Capital:** Oslo
> **Currency:** NOK
> **Central Bank:** [[NOR-central-bank|Central Bank of Norway (stub)]]

## 💱 FX Snapshot
<!-- LIVE:FXRATE:START -->
| Metric | Value |
|---|---|
| USD → NOK | `9.3271` |
| Source | ECB reference rate (via frankfurter.app) |
| As of | 2026-08-28 |
<!-- LIVE:FXRATE:END -->

## 🏛️ Monetary Authority
- [[NOR-central-bank|Central Bank of Norway (stub)]]

## 🔗 Connected Payment Rails
- [[SWIFT-rail|Society for Worldwide Interbank Financial Telecommunication]]

## 🗺️ Graph Context
- Region MOC: [[Europe-MOC]]
- All entities of this type: `dataview` query in [[Countries-MOC]]

## 📝 Notes
> Add your own notes below this line — the daemon never touches this section.
