---
type: "country"
iso2: "CN"
iso3: "CHN"
region: "Asia"
subregion: "Eastern Asia"
currency: "CNY"
central_bank: "CHN-central-bank"
population: "N/A"
tags:
  - finance/country
  - region/asia
last_updated: "2026-08-31 09:03 UTC"
---
# 🏦 China — Financial Tear Sheet

> [!info] Quick Facts
> **Region:** Asia / Eastern Asia
> **Capital:** Beijing
> **Currency:** CNY
> **Central Bank:** [[CHN-central-bank|Central Bank of China]]

## 💱 FX Snapshot
<!-- LIVE:FXRATE:START -->
| Metric | Value |
|---|---|
| USD → CNY | `6.7209` |
| Source | ECB reference rate (via frankfurter.app) |
| As of | 2026-08-28 |
<!-- LIVE:FXRATE:END -->

## 🏛️ Monetary Authority
- [[CHN-central-bank|Central Bank of China]]

## 🔗 Connected Payment Rails
- [[CIPS-rail|Cross-Border Interbank Payment System]]
- [[SWIFT-rail|Society for Worldwide Interbank Financial Telecommunication]]

## 🗺️ Graph Context
- Region MOC: [[Asia-MOC]]
- All entities of this type: `dataview` query in [[Countries-MOC]]

## 📝 Notes
> Add your own notes below this line — the daemon never touches this section.
