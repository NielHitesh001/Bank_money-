---
type: "country"
iso2: "BE"
iso3: "BEL"
region: "Europe"
subregion: "Western Europe"
currency: "EUR"
central_bank: "BEL-central-bank"
population: "N/A"
tags:
  - finance/country
  - region/europe
last_updated: "2026-08-31 09:03 UTC"
---
# 🏦 Belgium — Financial Tear Sheet

> [!info] Quick Facts
> **Region:** Europe / Western Europe
> **Capital:** Brussels
> **Currency:** EUR
> **Central Bank:** [[BEL-central-bank|Central Bank of Belgium (stub)]]

## 💱 FX Snapshot
<!-- LIVE:FXRATE:START -->
| Metric | Value |
|---|---|
| USD → EUR | `0.8589` |
| Source | ECB reference rate (via frankfurter.app) |
| As of | 2026-08-28 |
<!-- LIVE:FXRATE:END -->

## 🏛️ Monetary Authority
- [[BEL-central-bank|Central Bank of Belgium (stub)]]

## 🔗 Connected Payment Rails
- [[SWIFT-rail|Society for Worldwide Interbank Financial Telecommunication]]

## 🗺️ Graph Context
- Region MOC: [[Europe-MOC]]
- All entities of this type: `dataview` query in [[Countries-MOC]]

## 📝 Notes
> Add your own notes below this line — the daemon never touches this section.
