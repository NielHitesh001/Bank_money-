---
type: "country"
iso2: "DK"
iso3: "DNK"
region: "Europe"
subregion: "Northern Europe"
currency: "DKK"
central_bank: "DNK-central-bank"
population: "N/A"
tags:
  - finance/country
  - region/europe
last_updated: "2026-08-31 09:03 UTC"
---
# 🏦 Denmark — Financial Tear Sheet

> [!info] Quick Facts
> **Region:** Europe / Northern Europe
> **Capital:** Copenhagen
> **Currency:** DKK
> **Central Bank:** [[DNK-central-bank|Central Bank of Denmark (stub)]]

## 💱 FX Snapshot
<!-- LIVE:FXRATE:START -->
| Metric | Value |
|---|---|
| USD → DKK | `6.4200` |
| Source | ECB reference rate (via frankfurter.app) |
| As of | 2026-08-28 |
<!-- LIVE:FXRATE:END -->

## 🏛️ Monetary Authority
- [[DNK-central-bank|Central Bank of Denmark (stub)]]

## 🔗 Connected Payment Rails
- [[SWIFT-rail|Society for Worldwide Interbank Financial Telecommunication]]

## 🗺️ Graph Context
- Region MOC: [[Europe-MOC]]
- All entities of this type: `dataview` query in [[Countries-MOC]]

## 📝 Notes
> Add your own notes below this line — the daemon never touches this section.
