---
type: "country"
iso2: "DZ"
iso3: "DZA"
region: "Africa"
subregion: "Northern Africa"
currency: "DZD"
central_bank: "DZA-central-bank"
population: "N/A"
tags:
  - finance/country
  - region/africa
last_updated: "2026-08-31 09:03 UTC"
---
# 🏦 Algeria — Financial Tear Sheet

> [!info] Quick Facts
> **Region:** Africa / Northern Africa
> **Capital:** Algiers
> **Currency:** DZD
> **Central Bank:** [[DZA-central-bank|Central Bank of Algeria (stub)]]

## 💱 FX Snapshot
<!-- LIVE:FXRATE:START -->
| Metric | Value |
|---|---|
| USD → DZD | `N/A` |
| Source | ECB reference rate (via frankfurter.app) |
| As of | 2026-08-28 |
<!-- LIVE:FXRATE:END -->

## 🏛️ Monetary Authority
- [[DZA-central-bank|Central Bank of Algeria (stub)]]

## 🔗 Connected Payment Rails
- [[SWIFT-rail|Society for Worldwide Interbank Financial Telecommunication]]

## 🗺️ Graph Context
- Region MOC: [[Africa-MOC]]
- All entities of this type: `dataview` query in [[Countries-MOC]]

## 📝 Notes
> Add your own notes below this line — the daemon never touches this section.
