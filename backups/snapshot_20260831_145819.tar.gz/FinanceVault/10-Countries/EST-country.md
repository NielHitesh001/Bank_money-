---
type: "country"
iso2: "EE"
iso3: "EST"
region: "Europe"
subregion: "Northern Europe"
currency: "EUR"
central_bank: "EST-central-bank"
population: "N/A"
tags:
  - finance/country
  - region/europe
last_updated: "2026-08-31 09:03 UTC"
---
# 🏦 Estonia — Financial Tear Sheet

> [!info] Quick Facts
> **Region:** Europe / Northern Europe
> **Capital:** Tallinn
> **Currency:** EUR
> **Central Bank:** [[EST-central-bank|Central Bank of Estonia (stub)]]

## 💱 FX Snapshot
<!-- LIVE:FXRATE:START -->
| Metric | Value |
|---|---|
| USD → EUR | `0.8589` |
| Source | ECB reference rate (via frankfurter.app) |
| As of | 2026-08-28 |
<!-- LIVE:FXRATE:END -->

## 🏛️ Monetary Authority
- [[EST-central-bank|Central Bank of Estonia (stub)]]

## 🔗 Connected Payment Rails
- [[SWIFT-rail|Society for Worldwide Interbank Financial Telecommunication]]

## 🗺️ Graph Context
- Region MOC: [[Europe-MOC]]
- All entities of this type: `dataview` query in [[Countries-MOC]]

## 📝 Notes
> Add your own notes below this line — the daemon never touches this section.
