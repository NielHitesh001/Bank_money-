---
type: "country"
iso2: "HR"
iso3: "HRV"
region: "Europe"
subregion: "Southeast Europe"
currency: "EUR"
central_bank: "HRV-central-bank"
population: "N/A"
tags:
  - finance/country
  - region/europe
last_updated: "2026-08-31 09:03 UTC"
---
# 🏦 Croatia — Financial Tear Sheet

> [!info] Quick Facts
> **Region:** Europe / Southeast Europe
> **Capital:** Zagreb
> **Currency:** EUR
> **Central Bank:** [[HRV-central-bank|Central Bank of Croatia (stub)]]

## 💱 FX Snapshot
<!-- LIVE:FXRATE:START -->
| Metric | Value |
|---|---|
| USD → EUR | `0.8589` |
| Source | ECB reference rate (via frankfurter.app) |
| As of | 2026-08-28 |
<!-- LIVE:FXRATE:END -->

## 🏛️ Monetary Authority
- [[HRV-central-bank|Central Bank of Croatia (stub)]]

## 🔗 Connected Payment Rails
- [[SWIFT-rail|Society for Worldwide Interbank Financial Telecommunication]]

## 🗺️ Graph Context
- Region MOC: [[Europe-MOC]]
- All entities of this type: `dataview` query in [[Countries-MOC]]

## 📝 Notes
> Add your own notes below this line — the daemon never touches this section.
