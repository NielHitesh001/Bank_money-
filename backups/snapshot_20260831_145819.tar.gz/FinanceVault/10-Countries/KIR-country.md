---
type: "country"
iso2: "KI"
iso3: "KIR"
region: "Oceania"
subregion: "Micronesia"
currency: "AUD"
central_bank: "KIR-central-bank"
population: "N/A"
tags:
  - finance/country
  - region/oceania
last_updated: "2026-08-31 09:03 UTC"
---
# 🏦 Kiribati — Financial Tear Sheet

> [!info] Quick Facts
> **Region:** Oceania / Micronesia
> **Capital:** South Tarawa
> **Currency:** AUD
> **Central Bank:** [[KIR-central-bank|Central Bank of Kiribati (stub)]]

## 💱 FX Snapshot
<!-- LIVE:FXRATE:START -->
| Metric | Value |
|---|---|
| USD → AUD | `1.3899` |
| Source | ECB reference rate (via frankfurter.app) |
| As of | 2026-08-28 |
<!-- LIVE:FXRATE:END -->

## 🏛️ Monetary Authority
- [[KIR-central-bank|Central Bank of Kiribati (stub)]]

## 🔗 Connected Payment Rails
- [[SWIFT-rail|Society for Worldwide Interbank Financial Telecommunication]]

## 🗺️ Graph Context
- Region MOC: [[Oceania-MOC]]
- All entities of this type: `dataview` query in [[Countries-MOC]]

## 📝 Notes
> Add your own notes below this line — the daemon never touches this section.
