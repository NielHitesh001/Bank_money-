---
type: "currency"
currency_code: "KRW"
currency_name: "South Korean won"
currency_symbol: "\u20a9"
country_count: 1
tags:
  - finance/currency
last_updated: "2026-08-31 09:03 UTC"
---
# South Korean won (KRW) Currency Hub

## FX Snapshot
<!-- LIVE:FXRATE:START -->
| Metric | Value |
|---|---|
| USD -> KRW | `1374.5500` |
| Source | ECB reference rate (via frankfurter.app) |
| As of | 2026-08-28 |
<!-- LIVE:FXRATE:END -->

## Countries Using KRW
- [[KOR-country|South Korea]]

## Graph Context
- All currencies: see [[Currencies-MOC]]

## 📝 Notes
> Add your own notes below this line — the daemon never touches this section.
