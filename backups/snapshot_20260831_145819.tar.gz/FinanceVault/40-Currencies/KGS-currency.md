---
type: "currency"
currency_code: "KGS"
currency_name: "Kyrgyzstani som"
currency_symbol: "\u0441"
country_count: 1
tags:
  - finance/currency
last_updated: "2026-08-31 09:03 UTC"
---
# Kyrgyzstani som (KGS) Currency Hub

## FX Snapshot
<!-- LIVE:FXRATE:START -->
| Metric | Value |
|---|---|
| USD -> KGS | `N/A` |
| Source | ECB reference rate (via frankfurter.app) |
| As of | 2026-08-28 |
<!-- LIVE:FXRATE:END -->

## Countries Using KGS
- [[KGZ-country|Kyrgyzstan]]

## Graph Context
- All currencies: see [[Currencies-MOC]]

## 📝 Notes
> Add your own notes below this line — the daemon never touches this section.
