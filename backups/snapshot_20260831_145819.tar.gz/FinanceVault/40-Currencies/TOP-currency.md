---
type: "currency"
currency_code: "TOP"
currency_name: "Tongan pa\u02bbanga"
currency_symbol: "T$"
country_count: 1
tags:
  - finance/currency
last_updated: "2026-08-31 09:03 UTC"
---
# Tongan paʻanga (TOP) Currency Hub

## FX Snapshot
<!-- LIVE:FXRATE:START -->
| Metric | Value |
|---|---|
| USD -> TOP | `N/A` |
| Source | ECB reference rate (via frankfurter.app) |
| As of | 2026-08-28 |
<!-- LIVE:FXRATE:END -->

## Countries Using TOP
- [[TON-country|Tonga]]

## Graph Context
- All currencies: see [[Currencies-MOC]]

## 📝 Notes
> Add your own notes below this line — the daemon never touches this section.
