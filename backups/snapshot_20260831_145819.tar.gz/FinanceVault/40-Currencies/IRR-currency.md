---
type: "currency"
currency_code: "IRR"
currency_name: "Iranian rial"
currency_symbol: "\ufdfc"
country_count: 1
tags:
  - finance/currency
last_updated: "2026-08-31 09:03 UTC"
---
# Iranian rial (IRR) Currency Hub

## FX Snapshot
<!-- LIVE:FXRATE:START -->
| Metric | Value |
|---|---|
| USD -> IRR | `N/A` |
| Source | ECB reference rate (via frankfurter.app) |
| As of | 2026-08-28 |
<!-- LIVE:FXRATE:END -->

## Countries Using IRR
- [[IRN-country|Iran]]

## Graph Context
- All currencies: see [[Currencies-MOC]]

## 📝 Notes
> Add your own notes below this line — the daemon never touches this section.
