---
type: "currency"
currency_code: "PAB"
currency_name: "Panamanian balboa"
currency_symbol: "B/."
country_count: 1
tags:
  - finance/currency
last_updated: "2026-08-31 09:03 UTC"
---
# Panamanian balboa (PAB) Currency Hub

## FX Snapshot
<!-- LIVE:FXRATE:START -->
| Metric | Value |
|---|---|
| USD -> PAB | `N/A` |
| Source | ECB reference rate (via frankfurter.app) |
| As of | 2026-08-28 |
<!-- LIVE:FXRATE:END -->

## Countries Using PAB
- [[PAN-country|Panama]]

## Graph Context
- All currencies: see [[Currencies-MOC]]

## 📝 Notes
> Add your own notes below this line — the daemon never touches this section.
